import yaml

class APMSCompiler:
    def __init__(self, path):
        self.path = path

    def compile(self):
        with open(self.path) as f:
            return yaml.safe_load(f)
