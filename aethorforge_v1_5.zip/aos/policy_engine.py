class PolicyEngine:
    def __init__(self, m):
        self.m = m

    def evaluate(self, req):
        caps = self.m.get("capabilities", [])
        for c in caps:
            if c["name"] == req["capability"]:
                return {"decision": "allow"}
        return {"decision": "deny"}
