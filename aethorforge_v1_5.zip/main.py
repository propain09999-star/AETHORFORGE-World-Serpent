import argparse
from aos.policy_compiler import APMSCompiler
from aos.policy_engine import PolicyEngine

def run():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', default='policy/aos.manifest.yaml')
    sub = parser.add_subparsers(dest='cmd')

    c = sub.add_parser('check')
    c.add_argument('--agent', required=True)
    c.add_argument('--capability', required=True)
    c.add_argument('--target', required=True)

    args = parser.parse_args()

    compiled = APMSCompiler(args.manifest).compile()
    engine = PolicyEngine(compiled)

    res = engine.evaluate({
        "agent_id": args.agent,
        "capability": args.capability,
        "target": args.target
    })
    print(res)

if __name__ == "__main__":
    run()
