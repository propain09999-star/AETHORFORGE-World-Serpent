# AETHORFORGE v1.5 — Global Cyber Command Hub
### The World Serpent: Quantum-Hardened Hierarchical DMAAAS Platform

AETHORFORGE is a modular, agentic security platform.

Run:
pip install -r requirements.txt
python main.py check --agent GRIT-SCOUT-001 --capability net.scan.port --target scope:approved_assets
