
class ArchitectGovernor:
    def __init__(self):
        self.mode = "NORMAL"

    def set_mode(self, m):
        self.mode = m
        return self.mode
