
import random

class Node:
    def __init__(self, i):
        self.id = f"node-{i}"
        self.load = random.random()

    def heartbeat(self):
        return {"id": self.id, "load": self.load}

class Swarm:
    def __init__(self, n=5):
        self.nodes = [Node(i) for i in range(n)]

    def collect(self):
        return [n.heartbeat() for n in self.nodes]
