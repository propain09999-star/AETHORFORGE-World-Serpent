# AETHORFORGE v1.6 Architecture Spec
Hybrid OS-style agent system.