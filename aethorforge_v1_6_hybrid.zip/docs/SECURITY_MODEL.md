# Threat Model
Assumes hostile environment.