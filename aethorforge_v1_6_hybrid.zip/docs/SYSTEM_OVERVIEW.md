# System Overview
Event-driven agentic OS.