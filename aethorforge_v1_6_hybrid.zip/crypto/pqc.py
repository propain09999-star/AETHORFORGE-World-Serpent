
import hashlib
import uuid

class KyberSim:
    def encapsulate(self, data):
        return {"ct": hashlib.sha256(data.encode()).hexdigest()}

class DilithiumSim:
    def sign(self, data):
        return hashlib.sha512(data.encode()).hexdigest()
