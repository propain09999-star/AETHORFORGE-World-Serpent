
from golden_dome.swarm import Swarm

def test_swarm():
    s = Swarm()
    assert len(s.collect()) > 0
