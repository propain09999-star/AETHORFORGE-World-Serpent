
from dsl.compiler import PolicyDSLCompiler

def test_dsl():
    c = PolicyDSLCompiler().compile("ALLOW x")
    assert c["rules"][0]["action"] == "allow"
