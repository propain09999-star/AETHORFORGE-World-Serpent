
class SecureLead:
    def analyze(self, event):
        return {"risk": "low"}
