
class PolicyDSLCompiler:
    def compile(self, text):
        rules = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            if line.startswith("ALLOW"):
                rules.append({"action": "allow"})
            if line.startswith("DENY"):
                rules.append({"action": "deny"})
        return {"rules": rules}
