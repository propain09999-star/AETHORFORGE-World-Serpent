
import random

class Mesh:
    def __init__(self, n=5):
        self.nodes = [{"id": f"n{i}", "lat": random.randint(10,100)} for i in range(n)]

    def broadcast(self, msg):
        return {"msg": msg, "nodes": self.nodes}
