
from aos.kernel import AOSKernel
from dsl.compiler import PolicyDSLCompiler
from aos.policy_engine import PolicyEngineV2

def load_policy():
    dsl = open("policy.dsl").read()
    compiled = PolicyDSLCompiler().compile(dsl)
    return compiled

def run():
    compiled = load_policy()
    engine = PolicyEngineV2(compiled)
    kernel = AOSKernel(engine)

    result = kernel.execute({
        "agent_id": "GRIT-1",
        "capability": "net.scan.port",
        "target": "scope:approved_assets"
    })

    print(result)

if __name__ == "__main__":
    run()
