
class PolicyEngineV2:
    def __init__(self, compiled):
        self.compiled = compiled

    def evaluate(self, req):
        rules = self.compiled.get("rules", [])

        for r in rules:
            if r["action"] == "allow":
                return {"decision": "allow"}
            if r["action"] == "deny":
                return {"decision": "deny"}

        return {"decision": "deny"}
