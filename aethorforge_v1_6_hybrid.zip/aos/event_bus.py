
class EventBus:
    def __init__(self):
        self.events = []

    def emit(self, t, payload):
        e = {"type": t, "payload": payload}
        self.events.append(e)
        return e
