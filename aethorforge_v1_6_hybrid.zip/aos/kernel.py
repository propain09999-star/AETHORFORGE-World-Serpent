
from aos.event_bus import EventBus

class AOSKernel:
    def __init__(self, engine):
        self.engine = engine
        self.bus = EventBus()

    def execute(self, req):
        decision = self.engine.evaluate(req)
        self.bus.emit("POLICY_EVALUATED", decision)

        if decision["decision"] == "allow":
            self.bus.emit("EXEC_GRANTED", req)
            return {"status": "ok", "decision": decision}

        self.bus.emit("EXEC_DENIED", req)
        return {"status": "blocked", "decision": decision}
