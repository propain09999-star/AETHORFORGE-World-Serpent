
ALLOW net.scan.port IF scope == approved_assets
DENY net.scan.port IF target == external
