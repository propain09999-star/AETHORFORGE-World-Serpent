
- Add real PQC cryptography (production)
- Add distributed networking (real sockets)
- Add auth layer for agents
- Add database event store
- Add observability stack (metrics/logs/traces)
